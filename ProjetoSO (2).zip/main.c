//INTEGRANTES: FELIPE KONISHI BRUM RA: 10417412
//             TIAGO TERAOKA E SÁ RA: 10418485



#include <stdio.h>

#define NUM_FRAMES 16         // Exemplo de número de frames físicos
#define NUM_PAGINAS 32        // Exemplo de número de páginas virtuais
#define TAMANHO_PAGINA 256    // Tamanho de cada página/frame

// Estrutura para um frame da memória física
typedef struct {
    int ocupado;            // 0 para livre, 1 para ocupado
    int pagina_virtual;     // Página virtual mapeada para este frame
} Frame;

// Estrutura para uma página da memória virtual
typedef struct {
    int carregada;          // 0 se não está na RAM, 1 se está
    int frame;              // Frame correspondente, se estiver carregada
} PaginaVirtual;

// Entrada da Tabela de Páginas
typedef struct {
    int num_frame;          // Número do frame correspondente à página virtual
    int valido;             // 0 se a página não está na RAM, 1 se está
} EntradaTabelaPaginas;

// Estrutura para representar um processo simples
typedef struct {
    int id;                 // Identificador do processo
    int enderecos[10];      // Endereços virtuais que o processo tenta acessar
} Processo;

// Declaração das estruturas de dados
Frame memoria_fisica[NUM_FRAMES];            // Memória física (conjunto de frames)
PaginaVirtual memoria_virtual[NUM_PAGINAS];  // Memória virtual (conjunto de páginas)
EntradaTabelaPaginas tabela_paginas[NUM_PAGINAS]; // Tabela de páginas
Processo processo;                           // Processo

// Função para inicializar a memória física
void inicializar_memoria_fisica() {
    for (int i = 0; i < NUM_FRAMES; i++) {
        memoria_fisica[i].ocupado = 0;        // Frame livre
        memoria_fisica[i].pagina_virtual = -1; // Nenhuma página mapeada
    }
}

// Função para inicializar a memória virtual
void inicializar_memoria_virtual() {
    for (int i = 0; i < NUM_PAGINAS; i++) {
        memoria_virtual[i].carregada = 0;     // Página não carregada
        memoria_virtual[i].frame = -1;        // Nenhum frame alocado
    }
}

// Função para inicializar a tabela de páginas
void inicializar_tabela_paginas() {
    for (int i = 0; i < NUM_PAGINAS; i++) {
        tabela_paginas[i].num_frame = -1;     // Nenhum frame mapeado
        tabela_paginas[i].valido = 0;         // Entrada inválida (página não na RAM)
    }
}

// Função para traduzir um endereço virtual para físico
int traduzir_endereco(int endereco_virtual) {
    int num_pagina = endereco_virtual / TAMANHO_PAGINA;  // Número da página
    int offset = endereco_virtual % TAMANHO_PAGINA;      // Offset dentro da página

    // Verifica se a página está mapeada na tabela de páginas
    if (tabela_paginas[num_pagina].valido == 1) {
        int num_frame = tabela_paginas[num_pagina].num_frame;
        int endereco_fisico = num_frame * TAMANHO_PAGINA + offset;
        return endereco_fisico;
    } else {
        printf("Page Fault! Página %d não está na RAM.\n", num_pagina);
        return -1;  // Indica um page fault
    }
}

// Função para alocar uma página virtual em um frame físico
void alocar_pagina(int num_pagina) {
    // Procura um frame livre na memória física
    for (int i = 0; i < NUM_FRAMES; i++) {
        if (memoria_fisica[i].ocupado == 0) {  // Frame está livre
            memoria_fisica[i].ocupado = 1;     // Marca o frame como ocupado
            memoria_fisica[i].pagina_virtual = num_pagina; // Mapeia a página para o frame

            // Atualiza a memória virtual e a tabela de páginas
            memoria_virtual[num_pagina].carregada = 1;
            memoria_virtual[num_pagina].frame = i;

            tabela_paginas[num_pagina].num_frame = i;
            tabela_paginas[num_pagina].valido = 1;

            printf("Página %d alocada no frame %d.\n", num_pagina, i);
            return;
        }
    }

    printf("Erro: não há frames livres.\n");
}

// Função principal para testar o simulador
int main() {
    // Inicializa as estruturas de memória e tabela de páginas
    inicializar_memoria_fisica();
    inicializar_memoria_virtual();
    inicializar_tabela_paginas();

    // Configura um processo de teste
    processo.id = 1;
    processo.enderecos[0] = 512;  // Endereço virtual 512 (pertence à página 2)
    processo.enderecos[1] = 1280; // Endereço virtual 1280 (pertence à página 5)

    // Aloca páginas para os endereços virtuais do processo
    alocar_pagina(processo.enderecos[0] / TAMANHO_PAGINA);  // Página 2
    alocar_pagina(processo.enderecos[1] / TAMANHO_PAGINA);  // Página 5

    // Tradução dos endereços virtuais para endereços físicos
    int endereco_fisico = traduzir_endereco(processo.enderecos[0]);
    if (endereco_fisico != -1) {
        printf("Endereço virtual %d traduzido para físico %d.\n", processo.enderecos[0], endereco_fisico);
    }

    endereco_fisico = traduzir_endereco(processo.enderecos[1]);
    if (endereco_fisico != -1) {
        printf("Endereço virtual %d traduzido para físico %d.\n", processo.enderecos[1], endereco_fisico);
    }

    return 0;
}
